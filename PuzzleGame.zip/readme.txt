------------------------------------------------------------------------------------------------------------------------
This assignment was made for programming langauges at UCF with Professor Rick Leinacker.

The main page, index.html, lets you choose which puzzle you want to play and see the images before hand.

Puzzle 1 is demonstrating the use of the animation function in jQuery. It uses 4 buttons
to move one out of place peice to complete the puzzle. These include up, down, left, and right.

There is also a slider with a number representing how many pixels the button presses do. To help
make larger movements you can slide that up to 100 pixels and to help with precise movements you can 
slide that down to 1 pixel. This allows for a great range of movement to help make it more enjoyable rather
than moving pixel by pixel for all etternity.

Puzzle 2 is demonstrating the use of the draggable function in jQuery. It is simply you clicking and holding on
a puzzle piece and moving it in the whitespace provided to complete and match the example photo. 

Both puzzles also have a home button to return to the main page (index.html) and will reset the puzzle for you,
if you wanted to play it again. 

Andrew Fugate - 02/25/2024 - UCF PL - Spring 2024
------------------------------------------------------------------------------------------------------------------------